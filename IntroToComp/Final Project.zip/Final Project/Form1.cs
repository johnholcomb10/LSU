using System;
using System.IO;
using System.Text;
using System.Xml.Linq;
using System.Text.Json;
using System.Text.RegularExpressions;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Final_Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            label3.Text = "";

            button2.Visible = false;
            label4.Visible = false;
            label9.Visible = false;
            label10.Visible = false;
            label11.Visible = false;
            label12.Visible = false;
            textBox3.Visible = false;
            textBox4.Visible = false;
            textBox5.Visible = false;
            textBox6.Visible = false;
            textBox7.Visible = false;
        }

        private bool IsValidName(string name)
        {
            return !string.IsNullOrWhiteSpace(name);
        }

        private bool IsValidEmail(string email)
        {
            return Regex.IsMatch(email, @"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$");
        }

        private bool IsValidCardNumber(string card)
        {
            return card.Length == 16 && card.All(char.IsDigit);
        }

        private bool IsValidExpiration(string exp)
        {
            // Simple MM/YY format check
            return System.Text.RegularExpressions.Regex.IsMatch(exp, @"^(0[1-9]|1[0-2])\/\d{2}$");
        }

        private bool IsValidCVV(string cvv)
        {
            return cvv.Length == 3 && cvv.All(char.IsDigit);
        }

        private bool IsValidViewingID(string id)
        {
            return !string.IsNullOrWhiteSpace(id);
        }

        private bool ViewingIDExists(string viewingID)
        {
            try
            {
                string path = Path.Combine(Application.StartupPath, "movies.json");

                if (!File.Exists(path))
                    return false;

                string json = File.ReadAllText(path);
                List<Movie> movies = JsonSerializer.Deserialize<List<Movie>>(json);

                if (movies == null)
                    return false;

                return movies.Any(m =>
                    m.ViewingID.Equals(viewingID, StringComparison.OrdinalIgnoreCase));
            }
            catch
            {
                return false;
            }
        }

        private Movie GetMovieByViewingID(string viewingID)
        {
            try
            {
                string path = Path.Combine(Application.StartupPath, "movies.json");

                if (!File.Exists(path))
                    return null;

                string json = File.ReadAllText(path);
                List<Movie> movies = JsonSerializer.Deserialize<List<Movie>>(json);

                return movies?.FirstOrDefault(m =>
                    m.ViewingID.Equals(viewingID, StringComparison.OrdinalIgnoreCase));
            }
            catch
            {
                return null;
            }
        }

        private void UpdateTicketsSold(string viewingID)
        {
            string path = Path.Combine(Application.StartupPath, "movies.json");

            string json = File.ReadAllText(path);
            List<Movie> movies = JsonSerializer.Deserialize<List<Movie>>(json);

            var movie = movies.FirstOrDefault(m =>
                m.ViewingID.Equals(viewingID, StringComparison.OrdinalIgnoreCase));

            if (movie != null)
            {
                movie.TicketsSold++;

                string updatedJson = JsonSerializer.Serialize(
                    movies,
                    new JsonSerializerOptions { WriteIndented = true });

                File.WriteAllText(path, updatedJson);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int age = 0;
            int price = 0;
            string type = "";

            if (!int.TryParse(textBox2.Text, out age))
            {
                label3.Text = "Please enter a valid age.";
                return;
            }
            else if (age >= 1 && age <= 17)
            {
                price = 0;
                type = "Child";
            }
            else if (age >= 18 && age <= 54)
            {
                price = 15;
                type = "Adult";
            }
            else
            {
                price = 10;
                type = "Senior";
            }

            label3.Text = String.Format("Type: {0} | Price: ${1}", type, price);

            button2.Visible = true;
            label4.Visible = true;
            label9.Visible = true;
            label10.Visible = true;
            label11.Visible = true;
            label12.Visible = true;
            textBox3.Visible = true;
            textBox4.Visible = true;
            textBox5.Visible = true;
            textBox6.Visible = true;
            textBox7.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text.Trim();
            string email = textBox3.Text.Trim();
            string card = textBox4.Text.Trim();
            string exp = textBox6.Text.Trim();
            string cvv = textBox5.Text.Trim();
            string viewingID = textBox7.Text.Trim();

            // Validation
            if (!IsValidName(name))
            {
                MessageBox.Show("Enter a valid name.");
                return;
            }

            if (!IsValidEmail(email))
            {
                MessageBox.Show("Enter a valid email address.");
                return;
            }

            if (!IsValidCardNumber(card))
            {
                MessageBox.Show("Card must be 16 digits.");
                return;
            }

            if (!IsValidExpiration(exp))
            {
                MessageBox.Show("Expiration must be MM/YY.");
                return;
            }

            if (!IsValidCVV(cvv))
            {
                MessageBox.Show("CVV must be 3 digits.");
                return;
            }

            if (!IsValidViewingID(viewingID))
            {
                MessageBox.Show("Enter a valid Viewing ID.");
                return;
            }

            if (!ViewingIDExists(viewingID))
            {
                MessageBox.Show("Viewing ID does not exist. Please select a valid movie showing.");
                return;
            }

            Movie selectedMovie = GetMovieByViewingID(viewingID);

            if (selectedMovie == null)
            {
                MessageBox.Show("Viewing not found.");
                return;
            }

            if (selectedMovie.TicketsSold >= selectedMovie.Capacity)
            {
                MessageBox.Show("This showing is sold out.");
                return;
            }

            try
            {
                string path = Path.Combine(Application.StartupPath, "purchases.json");

                List<Purchase> purchases;

                // Load existing or create new list
                if (File.Exists(path))
                {
                    string existingJson = File.ReadAllText(path);
                    purchases = JsonSerializer.Deserialize<List<Purchase>>(existingJson) ?? new List<Purchase>();
                }
                else
                {
                    purchases = new List<Purchase>();
                }

                // Create purchase
                Purchase newPurchase = new Purchase
                {
                    Name = name,
                    Email = email,
                    CreditCardNumber = card,
                    Expiration = exp,
                    CVV = cvv,
                    ViewingID = viewingID
                };

                purchases.Add(newPurchase);

                // Save back to file
                string updatedJson = JsonSerializer.Serialize(purchases, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(path, updatedJson);

                UpdateTicketsSold(viewingID);

                MessageBox.Show("Purchase saved successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving purchase: " + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string path = Path.Combine(Application.StartupPath, "movies.json");

                if (!File.Exists(path))
                {
                    MessageBox.Show("movies.json not found.");
                    return;
                }

                string json = File.ReadAllText(path);
                List<Movie> movies = JsonSerializer.Deserialize<List<Movie>>(json);

                if (movies == null || movies.Count == 0)
                {
                    MessageBox.Show("No movie showings available.");
                    return;
                }

                // Build display text
                StringBuilder sb = new StringBuilder();

                sb.AppendLine("NOW SHOWING");
                sb.AppendLine(new string('-', 30));
                sb.AppendLine();

                foreach (var movie in movies)
                {
                    sb.AppendLine(movie.ViewingID);
                    sb.AppendLine(movie.Title);
                    sb.AppendLine($"Time: {movie.Time}");
                    sb.AppendLine($"Auditorium: {movie.Auditorium}");
                    sb.AppendLine($"Capacity: {movie.Capacity}");
                    sb.AppendLine($"Tickets Sold: {movie.TicketsSold}");
                    sb.AppendLine(new string('-', 30));
                }

                MessageBox.Show(sb.ToString(), "Cinema Showings");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading movies: " + ex.Message);
            }
        }
    }
}